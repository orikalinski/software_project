#ifndef MAIN_AUX_H_
#define MAIN_AUX_H_
/**
 *get input from user and convert to a point
 */
void readCoordinates(int dim, double* coordinates);
#endif
